<?php
/**
 * Plugin Name: Voice ADD for HivePress
 * Plugin URI:  https://uaserver.pp.ua/voice-add-hivepress/
 * Description: Голосове додавання оголошень у HivePress з фото, атрибутами та монетизацією.
 * Version:     1.0.0
 * Author:      UAServer
 * Author URI:  https://uaserver.pp.ua/
 * License:     GPLv2 or later
 * Text Domain: voice-add-hp
 * Requires at least: 5.8
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) exit;

define('VAHP_VERSION', '1.0.0');
define('VAHP_FILE', __FILE__);
define('VAHP_FREE_LIMIT', 25);
define('VAHP_GITHUB', 'your-github-username/voice-add-hivepress'); // <-- ЗМІНІТЬ НА СВІЙ РЕПОЗИТОРІЙ

// =====================================================================
// АВТООНОВЛЕННЯ З GITHUB
// =====================================================================
class VAHP_Updater {
    private $file, $slug, $repo;
    public function __construct($file, $repo) {
        $this->file = $file;
        $this->slug = dirname(plugin_basename($file));
        $this->repo = $repo;
        add_filter('pre_set_site_transient_update_plugins', [$this, 'check']);
        add_filter('plugins_api', [$this, 'info'], 10, 3);
    }
    public function check($t) {
        if (empty($t->checked)) return $t;
        $r = $this->remote();
        if ($r && version_compare(VAHP_VERSION, $r->version, '<')) {
            $t->response[plugin_basename($this->file)] = (object)[
                'slug' => $this->slug, 'new_version' => $r->version,
                'package' => $r->zip, 'url' => $r->url, 'tested' => '7.1',
            ];
        }
        return $t;
    }
    public function info($res, $action, $args) {
        if ($action !== 'plugin_information' || $args->slug !== $this->slug) return $res;
        $r = $this->remote();
        if (!$r) return $res;
        return (object)['name' => 'Voice ADD for HivePress', 'slug' => $this->slug,
            'version' => $r->version, 'download_link' => $r->zip,
            'tested' => '7.1', 'requires_php' => '7.4',
            'sections' => ['description' => 'Голосове додавання оголошень у HivePress.']];
    }
    private function remote() {
        $resp = wp_remote_get("https://api.github.com/repos/{$this->repo}/releases/latest",
            ['headers' => ['Accept' => 'application/json'], 'timeout' => 5]);
        if (is_wp_error($resp)) return null;
        $d = json_decode(wp_remote_retrieve_body($resp));
        if (!$d || !isset($d->tag_name)) return null;
        return (object)['version' => ltrim($d->tag_name, 'v'), 'zip' => $d->zipball_url, 'url' => $d->html_url];
    }
}
new VAHP_Updater(VAHP_FILE, VAHP_GITHUB);

// =====================================================================
// ХЕЛПЕРИ
// =====================================================================
function vahp_en() { return in_array(get_locale(), ['en_US','en_GB','en_CA','en_AU','en']); }
function vahp_t($ua, $en) { return vahp_en() ? $en : $ua; }
function vahp_count() { return (int) get_option('vahp_ops', 0); }
function vahp_inc() { update_option('vahp_ops', vahp_count() + 1); }
function vahp_limit() { return (int) get_option('vahp_free_limit', VAHP_FREE_LIMIT); }
function vahp_left() { return max(0, vahp_limit() - vahp_count()); }

// Перевірка PRO через ваш плагін монетизації
function vahp_pro() {
    if ( function_exists( 'wcc_check_user_premium' ) ) {
        return (bool) wcc_check_user_premium( get_current_user_id(), 4 ); // ID продукту = 4 для HivePress
    }
    return false;
}
function vahp_can() { return vahp_pro() || vahp_count() < vahp_limit(); }

// Отримання атрибутів HivePress
function vahp_get_attributes() {
    $attributes = [];
    if ( function_exists('hivepress') ) {
        $hp = hivepress();
        if ( isset($hp->attributes) ) {
            $all = $hp->attributes->get_all();
            foreach ( $all as $attr ) {
                $attributes[] = [
                    'name' => $attr['name'],
                    'type' => $attr['type'] ?? 'text',
                ];
            }
        }
    }
    return $attributes;
}

// =====================================================================
// АКТИВАЦІЯ
// =====================================================================
register_activation_hook(__FILE__, function () {
    add_option('vahp_ops', 0);
    add_option('vahp_draft', '0');
    add_option('vahp_rbg_api', '');
});

// =====================================================================
// МЕНЮ
// =====================================================================
add_action('admin_menu', function () {
    add_menu_page('Voice ADD HP', 'Voice ADD HP', 'manage_options', 'vahp_main', 'vahp_page_main', 'dashicons-microphone', 30);
    add_submenu_page('vahp_main', 'Налаштування', '⚙️ Налаштування', 'manage_options', 'vahp_settings', 'vahp_page_settings');
});

// =====================================================================
// СТОРІНКА НАЛАШТУВАНЬ
// =====================================================================
function vahp_page_settings() {
    if (isset($_POST['vahp_save']) && check_admin_referer('vahp_cfg')) {
        update_option('vahp_rbg_api', sanitize_text_field($_POST['rbg_api']));
        update_option('vahp_draft', isset($_POST['vahp_draft']) ? '1' : '0');
        echo '<div class="notice notice-success"><p>✅ Збережено!</p></div>';
    }
    $rbg = get_option('vahp_rbg_api', '');
    $draft = get_option('vahp_draft', '0');
    ?>
    <div class="wrap">
        <h1>⚙️ Налаштування Voice ADD HP</h1>
        <form method="post"><?php wp_nonce_field('vahp_cfg') ?>
        <table class="form-table">
            <tr><th>Remove.bg API Key</th>
                <td><input type="text" name="rbg_api" value="<?php echo esc_attr($rbg) ?>" style="width:340px" placeholder="tSZ2c5cR...">
                <p class="description">Отримайте ключ на remove.bg/api (50 фото/міс безкоштовно).</p></td></tr>
            <tr><th>Статус за замовчуванням</th>
                <td><label><input type="checkbox" name="vahp_draft" value="1" <?php checked($draft, '1') ?>> Зберігати як чернетку</label></td></tr>
        </table>
        <input type="hidden" name="vahp_save" value="1">
        <?php submit_button('Зберегти') ?>
        </form>
    </div>
    <?php
}

// =====================================================================
// ГОЛОВНА СТОРІНКА
// =====================================================================
function vahp_page_main() {
    $attrs = vahp_get_attributes();
    $pro = vahp_pro();
    $can = vahp_can();
    $has_rbg = !empty(get_option('vahp_rbg_api', ''));
    $draft = get_option('vahp_draft', '0') === '1';
    
    // Генерація шаблону
    $template = "ЗАГОЛОВОК: \nКАТЕГОРІЯ: \nОПИС: \n";
    foreach ($attrs as $a) {
        if ($a['type'] === 'select') {
            $template .= "Атрибут " . $a['name'] . " Значення \n";
        } else {
            $template .= $a['name'] . ": \n";
        }
    }
    ?>
    <style>
    @keyframes vahp_pulse { 0%,100%{opacity:1} 50%{opacity:.5} }
    </style>
    <div class="wrap">
        <h1>🎤 Voice ADD for HivePress <sup style="font-size:11px;color:#aaa">v<?php echo esc_html(VAHP_VERSION) ?></sup></h1>
        
        <?php if (!$pro) : ?>
        <div style="background:#fff3cd;padding:10px;border-radius:8px;margin-bottom:15px">
            📊 Залишилось: <strong><?php echo vahp_left() ?></strong>/<?php echo vahp_limit() ?>
            &nbsp; <a href="https://uaserver.pp.ua/voice-add-hivepress/" target="_blank" style="color:#c00;font-weight:bold">💰 Купити PRO</a>
        </div>
        <?php endif ?>

        <video id="vahp_cam" autoplay playsinline muted style="width:100%;max-height:280px;background:#111;border-radius:10px;margin-bottom:10px;object-fit:cover"></video>
        <div id="vahp_gal" style="display:flex;gap:5px;flex-wrap:wrap;margin-bottom:10px"></div>

        <?php if ($has_rbg) : ?>
        <div id="vahp_bg_wrap" style="background:#f8f9fa;padding:10px;border-radius:8px;margin-bottom:10px;display:none">
            <strong>Фон:</strong>
            <label><input type="radio" name="vahp_bg" value="original" checked> Оригінал</label>
            <label><input type="radio" name="vahp_bg" value="transparent"> Прозорий</label>
            <label><input type="radio" name="vahp_bg" value="ffffff"> Білий</label>
        </div>
        <?php endif ?>

        <div style="display:flex;gap:8px;margin-bottom:10px">
            <button id="vahp_photo" style="flex:1;padding:12px;background:#2271b1;color:#fff;border:none;border-radius:8px;cursor:pointer">📷 Фото</button>
            <button id="vahp_clr" style="flex:1;padding:12px;background:#6c757d;color:#fff;border:none;border-radius:8px;cursor:pointer">❌ Очистити</button>
        </div>

        <div id="vahp_bar" style="display:none;padding:10px;text-align:center;color:#fff;border-radius:8px;margin-bottom:10px"></div>

        <textarea id="vahp_ta" rows="15" style="width:100%;font-family:monospace;font-size:14px;padding:10px;border:2px solid #2271b1;border-radius:8px;"><?php echo esc_textarea($template); ?></textarea>
        
        <div style="margin-top:10px;display:flex;gap:8px">
            <button id="vahp_mic" style="flex:2;padding:14px;background:#1877F2;color:#fff;border:none;border-radius:8px;font-size:16px;font-weight:bold;cursor:pointer">🎤 ДИКТУВАТИ</button>
        </div>
        
        <button id="vahp_save" style="width:100%;margin-top:10px;padding:16px;background:#00a32a;color:#fff;border:none;border-radius:8px;font-size:18px;font-weight:bold;cursor:pointer">
            <?php echo $draft ? '➕ ЗБЕРЕГТИ ЯК ЧЕРНЕТКУ' : '➕ ОПУБЛІКУВАТИ'; ?>
        </button>

        <div id="vahp_msg" style="margin-top:15px;"></div>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function () {
        var photos = [], cam = null, listening = false;
        var vs = 'idle', vf = null;
        var has_rbg = <?php echo $has_rbg ? 'true' : 'false'; ?>;
        var can_save = <?php echo $can ? 'true' : 'false'; ?>;

        // Ініціалізація камери
        navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } })
            .then(function (stream) { cam = stream; document.getElementById('vahp_cam').srcObject = stream; })
            .catch(function (e) { console.log(e); });

        // Фото
        document.getElementById('vahp_photo').addEventListener('click', function () {
            var v = document.getElementById('vahp_cam');
            if (!v.videoWidth) return;
            var c = document.createElement('canvas');
            c.width = v.videoWidth; c.height = v.videoHeight;
            c.getContext('2d').drawImage(v, 0, 0);
            var d = c.toDataURL('image/jpeg', 0.82);
            photos.push(d);
            var img = document.createElement('img');
            img.src = d;
            img.style.cssText = 'width:60px;height:60px;object-fit:cover;border-radius:6px;border:2px solid #2271b1;cursor:pointer';
            img.addEventListener('click', function () { photos.splice(photos.indexOf(d), 1); img.remove(); });
            document.getElementById('vahp_gal').prepend(img);
            if (has_rbg) document.getElementById('vahp_bg_wrap').style.display = 'block';
        });

        document.getElementById('vahp_clr').addEventListener('click', function () {
            photos = []; document.getElementById('vahp_gal').innerHTML = '';
            if (has_rbg) document.getElementById('vahp_bg_wrap').style.display = 'none';
        });

        // Голос
        if (window.SpeechRecognition || window.webkitSpeechRecognition) {
            var SR = window.SpeechRecognition || window.webkitSpeechRecognition;
            var rec = new SR();
            rec.lang = <?php echo vahp_en() ? "'en-US'" : "'uk-UA'" ?>;
            rec.continuous = true; rec.interimResults = false;
            var mb = document.getElementById('vahp_mic');

            mb.addEventListener('click', function () {
                if (!listening) {
                    try {
                        rec.start(); listening = true;
                        mb.style.cssText = 'flex:2;padding:14px;background:#dc3545;color:#fff;border:none;border-radius:8px;font-size:16px;font-weight:bold;cursor:pointer;animation:vahp_pulse 1s infinite';
                        mb.textContent = '🛑 ЗУПИНИТИ';
                    } catch (e) { msg('Помилка: ' + e.message); }
                } else {
                    listening = false; try { rec.stop(); } catch(e) {}
                    mb.style.cssText = 'flex:2;padding:14px;background:#1877F2;color:#fff;border:none;border-radius:8px;font-size:16px;font-weight:bold;cursor:pointer';
                    mb.textContent = '🎤 ДИКТУВАТИ';
                }
            });

            rec.onresult = function (e) {
                var spoken = '';
                var res = e.results[e.results.length - 1];
                for (var i = 0; i < res.length; i++) { spoken = res[i].transcript.trim(); if (spoken) break; }
                var low = spoken.toLowerCase();

                // Логіка "Атрибут ... Значення ..."
                if (low.startsWith('атрибут ') || low.startsWith('attribute ')) {
                    var parts = spoken.split(/значення|value/i);
                    if (parts.length >= 2) {
                        var attrName = parts[0].replace(/атрибут|attribute/i, '').trim();
                        var attrVal = parts[1].trim();
                        var ta = document.getElementById('vahp_ta');
                        ta.value += "\nАтрибут " + attrName + ": " + attrVal;
                    }
                } else if (spoken.indexOf(':') !== -1) {
                    var ta = document.getElementById('vahp_ta');
                    ta.value += "\n" + spoken;
                } else {
                    var ta = document.getElementById('vahp_ta');
                    ta.value += "\n" + spoken;
                }
            };

            rec.onerror = function (e) { msg('Помилка голосу: ' + e.error); };
            rec.onend = function () { if (listening) setTimeout(function () { try { rec.start(); } catch (x) {} }, 100); };
        } else {
            document.getElementById('vahp_mic').disabled = true;
        }

        function msg(text) {
            var d = document.getElementById('vahp_msg');
            d.innerHTML = '<span style="color:red">' + text + '</span>';
        }

        // Збереження
        document.getElementById('vahp_save').addEventListener('click', function () {
            var self = this;
            if (!can_save) { msg('Ліміт вичерпано!'); return; }
            
            self.disabled = true; self.textContent = '⏳ ЗБЕРІГАЮ...';
            
            var bg = 'original';
            if (has_rbg && document.querySelector('input[name="vahp_bg"]:checked')) {
                bg = document.querySelector('input[name="vahp_bg"]:checked').value;
            }

            var fd = new FormData();
            fd.append('action', 'vahp_save_listing');
            fd.append('nonce', '<?php echo wp_create_nonce("vahp_save"); ?>');
            fd.append('text', document.getElementById('vahp_ta').value);
            fd.append('images', JSON.stringify(photos));
            fd.append('bg', bg);

            fetch(ajaxurl, { method: 'POST', body: fd })
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        document.getElementById('vahp_msg').innerHTML = '<span style="color:green">✅ Створено! ID: ' + data.data.id + '</span>';
                        photos = []; document.getElementById('vahp_gal').innerHTML = '';
                        document.getElementById('vahp_ta').value = '<?php echo esc_js($template); ?>';
                    } else {
                        msg('Помилка: ' + data.data);
                    }
                })
                .catch(err => msg('Помилка з\'єднання'))
                .finally(() => {
                    self.disabled = false;
                    self.textContent = '<?php echo $draft ? "➕ ЗБЕРЕГТИ ЯК ЧЕРНЕТКУ" : "➕ ОПУБЛІКУВАТИ"; ?>';
                });
        });
    });
    </script>
    <?php
}

// =====================================================================
// AJAX: ЗБЕРЕЖЕННЯ
// =====================================================================
add_action('wp_ajax_vahp_save_listing', function () {
    check_ajax_referer('vahp_save', 'nonce');
    if (!current_user_can('manage_options')) wp_send_json_error('Немає прав');
    if (!vahp_can()) wp_send_json_error('Ліміт вичерпано');

    $raw = sanitize_textarea_field($_POST['text'] ?? '');
    $imgs = json_decode(stripslashes($_POST['images'] ?? '[]'), true) ?: [];
    $bg = sanitize_text_field($_POST['bg'] ?? 'original');
    $draft = get_option('vahp_draft', '0') === '1';

    // Розбір тексту
    $data = [];
    $custom_attrs = [];
    foreach (explode("\n", $raw) as $line) {
        $line = trim($line);
        if (empty($line)) continue;
        if (stripos($line, 'атрибут ') === 0 && strpos($line, ':') !== false) {
            $parts = explode(':', $line, 2);
            $attr_name = trim(str_ireplace('атрибут', '', $parts[0]));
            $custom_attrs[$attr_name] = trim($parts[1]);
        } elseif (strpos($line, ':') !== false) {
            $parts = explode(':', $line, 2);
            $data[strtoupper(trim($parts[0]))] = trim($parts[1]);
        }
    }

    // Створення оголошення
    $post_data = [
        'post_title'   => $data['ЗАГОЛОВОК'] ?? $data['TITLE'] ?? 'Оголошення ' . gmdate('H:i:s'),
        'post_content' => $data['ОПИС'] ?? $data['DESCRIPTION'] ?? '',
        'post_status'  => $draft ? 'draft' : 'publish',
        'post_type'    => 'hp_listing',
    ];
    $pid = wp_insert_post($post_data);
    if (!$pid) wp_send_json_error('Не вдалося створити');

    // Категорія
    if (!empty($data['КАТЕГОРІЯ']) || !empty($data['CATEGORY'])) {
        $cat = $data['КАТЕГОРІЯ'] ?? $data['CATEGORY'];
        $term = term_exists($cat, 'hp_listing_category') ?: wp_insert_term($cat, 'hp_listing_category');
        if (!is_wp_error($term)) wp_set_object_terms($pid, (int)$term['term_id'], 'hp_listing_category');
    }

    // Кастомні атрибути
    $all_attrs = vahp_get_attributes();
    foreach ($custom_attrs as $name => $value) {
        $type = 'text';
        foreach ($all_attrs as $a) { if (strtolower($a['name']) === strtolower($name)) { $type = $a['type']; break; } }
        
        $meta_key = 'hp_' . sanitize_title($name);
        if (in_array($type, ['select', 'checkbox', 'radio'])) {
            $tax = 'hp_listing_' . sanitize_title($name);
            if (taxonomy_exists($tax)) {
                $term = term_exists($value, $tax) ?: wp_insert_term($value, $tax);
                if (!is_wp_error($term)) wp_set_object_terms($pid, (int)$term['term_id'], $tax);
            }
        } else {
            update_post_meta($pid, $meta_key, sanitize_text_field($value));
        }
    }

    // Фото
    if (!empty($imgs)) {
        require_once ABSPATH . 'wp-admin/includes/image.php';
        foreach ($imgs as $i => $b64) {
            if ($bg !== 'original' && !empty(get_option('vahp_rbg_api'))) {
                $b64 = vahp_remove_bg($b64, $bg);
            }
            $img = base64_decode(preg_replace('#^data:image/\w+;base64,#i', '', $b64));
            $file = wp_upload_bits('vahp_' . $pid . '_' . time() . '_' . $i . '.jpg', null, $img);
            if ($file['error']) continue;
            $aid = wp_insert_attachment(['post_mime_type' => 'image/jpeg', 'post_status' => 'inherit'], $file['file'], $pid);
            wp_update_attachment_metadata($aid, wp_generate_attachment_metadata($aid, $file['file']));
            if ($i === 0) set_post_thumbnail($pid, $aid);
        }
    }

    vahp_inc();
    wp_send_json_success(['id' => $pid]);
});

// =====================================================================
// REMOVE.BG
// =====================================================================
function vahp_remove_bg($b64, $bg) {
    $api = get_option('vahp_rbg_api', '');
    if (!$api) return $b64;
    $img_data = base64_decode(preg_replace('#^data:image/\w+;base64,#i', '', str_replace(' ', '+', $b64)));
    $r = wp_remote_post('https://api.remove.bg/v1.0/removebg', [
        'headers' => ['X-Api-Key' => $api],
        'body'    => ['image_file_b64' => base64_encode($img_data), 'size' => 'auto', 'format' => 'png', 'bg_color' => ($bg === 'transparent' ? '' : $bg)],
        'timeout' => 30,
    ]);
    if (is_wp_error($r)) return $b64;
    if (wp_remote_retrieve_response_code($r) !== 200) return $b64;
    return 'data:image/png;base64,' . base64_encode(wp_remote_retrieve_body($r));
}